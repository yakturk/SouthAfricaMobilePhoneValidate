package com.number.validator.demo.constant;

public enum FixStatus {
    PREFIX_ADDED,
    ALREADY_VALID,
    NOT_VALIDATED_NOT_APPROPRIATE_FOR_REGEX;
}
