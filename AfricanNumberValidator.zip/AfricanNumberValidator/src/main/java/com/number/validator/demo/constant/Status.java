package com.number.validator.demo.constant;

public enum Status {
    VALID,
    INVALID,
    FIXED;
}
